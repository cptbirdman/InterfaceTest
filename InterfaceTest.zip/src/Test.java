
/**
 * This is the main class which constructs a robot and runs it. 
 * This is to enable the robot.java class to be run as a Java application.
 * @author mbe5
 *
 */
public class Test {
	
	public static void main(String[] args)
	{
		Robot robot = new Robot();
		robot.Run();
	}
}
